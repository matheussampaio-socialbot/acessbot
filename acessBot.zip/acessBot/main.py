# import requests
import threading

from selenium import webdriver
from selenium.webdriver.common.proxy import Proxy, ProxyType


# def getProxy():
# 	proxy_list = "http://pubproxy.com/api/proxy?type=socks5"
# 	arquivo = open("proxy_word.txt", 'a')

# 	for o in range(10):
# 		request = requests.get(proxy_list)

# 		for i in request.json()['data']:
# 			if i['speed'] < '50':
# 				print(f"[+]IP: {i['ipPort']}\n[+]Speed: {i['speed']}\n")
# 	 			#arquivo.write(i['ipPort'] + '\n')

# 	arquivo.close()

# getProxy()

url = input("[+]URL~> ")
arquivo = open("proxy_word.txt", 'r')	


def main():
	for i in arquivo:
		print(f"[+]IP: {i}")

		firefox_capabilities = webdriver.DesiredCapabilities.FIREFOX
		firefox_capabilities['marionette'] = True

		firefox_capabilities['proxy'] = {
		  			"proxyType": "MANUAL",
		  		 	"httpProxy": i,
		  		 	"ftpProxy": i,
		  		 	"sslProxy": i}

		driver = webdriver.Firefox(capabilities=firefox_capabilities)
		driver.get(url)

	#arquivo.close()

	return


if __name__ == '__main__':

	for t in range(3):
		t = threading.Thread(target=main)
		t.start()